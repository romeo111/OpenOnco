"""Drug entity — KNOWLEDGE_SCHEMA_SPECIFICATION §5."""

from typing import Optional

from pydantic import Field

from .base import Base, NamePair, RegulatoryStatus


class Drug(Base):
    id: str
    names: NamePair
    atc_code: Optional[str] = None
    rxnorm_id: Optional[str] = None
    drug_class: Optional[str] = None  # e.g. "anti-CD20 monoclonal antibody"
    mechanism: Optional[str] = None

    regulatory_status: Optional[RegulatoryStatus] = None

    typical_dosing: Optional[str] = None
    formulations: list[str] = Field(default_factory=list)
    route: Optional[str] = None

    absolute_contraindications: list[str] = Field(default_factory=list)
    black_box_warnings: list[str] = Field(default_factory=list)
    major_interactions: list[str] = Field(default_factory=list)
    common_adverse_events: list[str] = Field(default_factory=list)
    serious_adverse_events: list[str] = Field(default_factory=list)
    # Some established records contain a clinically curated safety summary
    # instead of splitting events into common/serious buckets. Preserve it as
    # a first-class field rather than treating evidence-bearing content as an
    # unknown schema extension.
    # Historical YAML includes both plain statements and a small number of
    # labelled toxicity statements parsed by YAML as ``{label: detail}``.
    # Retain both forms so a schema upgrade cannot silently discard the
    # clinical qualifier embedded in those records.
    key_toxicities: list[str | dict[str, str]] = Field(default_factory=list)

    pharmacology: Optional[dict] = None  # half-life, clearance, etc.

    sources: list[str] = Field(default_factory=list)
    last_reviewed: Optional[str] = None
    reviewers: list[str] = Field(default_factory=list)
    notes: Optional[str] = None

    # Patient-mode lay-language blurb (1-2 sentences, Ukrainian, friendly
    # tone). Read by `engine.render._render_track_drugs` when present;
    # otherwise the renderer falls back to the drug_class vocabulary entry
    # in `engine._patient_vocabulary.DRUG_CLASS_PLAIN_UA` and finally to a
    # generic placeholder. NEVER consulted as a treatment-selection signal
    # (CHARTER §8.3 invariant — render-time only).
    notes_patient: Optional[str] = None
