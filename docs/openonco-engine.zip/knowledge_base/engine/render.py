"""HTML render layer — Plan / DiagnosticPlan / Revision → single-file
A4-printable HTML document.

Design language adapted from the project's reference patient deliverables
(infograph/*план лікування.html — gitignored, not the source of patient
data; only the visual idiom is borrowed): green medical palette, DM Serif
Display headings, Source Sans 3 body, badges + alerts + cards.
Layout adapted for A4 print + browser preview (no scroll-snap, single
flow column). UI patterns avoid automation bias per CHARTER §15.2 C6
(both tracks shown side-by-side, alternative is not buried, every
recommendation cites sources).

Three render entry points (one per document type):

- render_plan_html(plan_result, mdt=None) — treatment Plan with tracks
- render_diagnostic_brief_html(diag_result, mdt=None) — Workup Brief
- render_revision_note_html(prev, new, transition) — Revision Note

Each returns a complete single-file HTML string (CSS embedded). Caller
decides where to write it.

Per CHARTER §15.2 C7 — diagnostic banner mandatory in DiagnosticBrief,
treatment-Plan-not-applicable disclaimer surfaced above the fold.
"""

from __future__ import annotations

import html
from datetime import datetime, timezone
from typing import Optional, Union

from .diagnostic import _DIAGNOSTIC_BANNER, DiagnosticPlanResult
from .mdt_orchestrator import MDTOrchestrationResult
from .plan import PlanResult


# ── Embedded CSS (adapted from infograph reference, A4-tuned) ─────────────


_CSS = """
:root {
    --green-900: #0a2e1a; --green-800: #0d3f24; --green-700: #14532d;
    --green-600: #166534; --green-500: #16a34a; --green-400: #22c55e;
    --green-300: #4ade80; --green-200: #86efac; --green-100: #dcfce7;
    --green-50: #f0fdf4; --teal: #0d9488; --teal-dark: #115e59;
    --red-alert: #dc2626; --red-bg: #fef2f2;
    --amber-alert: #d97706; --amber-bg: #fffbeb;
    --blue-bg: #eff6ff; --blue-700: #1d4ed8;
    --purple-bg: #faf5ff; --purple-700: #7e22ce;
    --gray-50: #f9fafb; --gray-100: #f3f4f6; --gray-200: #e5e7eb;
    --gray-500: #6b7280; --gray-700: #374151; --gray-900: #111827;
    --font-display: 'Playfair Display', Georgia, serif;
    --font-body: 'Source Sans 3', 'Segoe UI', sans-serif;
    --font-mono: 'JetBrains Mono', Menlo, monospace;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
html { -webkit-font-smoothing: antialiased; }
body {
    font-family: var(--font-body); color: var(--gray-900);
    background: var(--gray-50); line-height: 1.55;
}
.page {
    max-width: 920px; margin: 0 auto; padding: 32px 48px;
    background: white; min-height: 100vh;
    box-shadow: 0 0 24px rgba(0,0,0,.04);
}
@media print {
    body { background: white; }
    .page { box-shadow: none; padding: 16mm; max-width: 100%; }
    @page { size: A4; margin: 12mm; }
    .no-print { display: none; }
    section { page-break-inside: avoid; }
}

/* Header */
.doc-header {
    border-bottom: 2px solid var(--green-700);
    padding-bottom: 18px; margin-bottom: 24px;
}
.doc-label {
    font-family: var(--font-mono); font-size: 11px; font-weight: 500;
    letter-spacing: 2px; text-transform: uppercase;
    color: var(--green-700); margin-bottom: 8px;
}
.doc-title {
    font-family: var(--font-display); font-size: 32px; line-height: 1.15;
    color: var(--green-900); margin-bottom: 6px;
}
.doc-sub {
    font-size: 14px; color: var(--gray-500);
    font-family: var(--font-mono);
}

/* Patient strip */
.patient-strip {
    background: var(--green-50); border-left: 4px solid var(--green-600);
    padding: 14px 18px; margin-bottom: 22px; border-radius: 4px;
}
.patient-strip .label {
    font-family: var(--font-mono); font-size: 10px; letter-spacing: 1px;
    text-transform: uppercase; color: var(--green-700); margin-bottom: 4px;
}
.patient-strip .value { font-size: 15px; color: var(--gray-900); }

/* Banner — diagnostic phase */
.banner {
    border-radius: 8px; padding: 16px 20px; margin-bottom: 22px;
    border-left: 4px solid; font-size: 14px; line-height: 1.55;
}
.banner--diagnostic {
    background: var(--amber-bg); border-color: var(--amber-alert);
    color: #92400e;
}
.banner--diagnostic strong { display: block; font-size: 15px; margin-bottom: 4px; }
.banner--info {
    background: var(--green-50); border-color: var(--green-500);
    color: var(--green-800);
}
.banner--alert {
    background: var(--red-bg); border-color: var(--red-alert);
    color: #991b1b;
}

/* Sections */
section { margin-bottom: 28px; }
h2 {
    font-family: var(--font-display); font-size: 22px; line-height: 1.2;
    color: var(--green-800); margin-bottom: 12px;
}
.section-sub {
    font-size: 13px; color: var(--gray-500); margin-bottom: 14px;
    font-family: var(--font-mono);
}
h3 {
    font-size: 14px; font-weight: 700; text-transform: uppercase;
    letter-spacing: 0.5px; margin: 18px 0 10px; color: var(--gray-700);
}

/* Tracks (treatment plan) */
.tracks { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.track {
    border: 1px solid var(--gray-200); border-radius: 10px; padding: 18px;
    background: white;
}
.track--default { border-left: 4px solid var(--green-600); }
.track--alternative { border-left: 4px solid var(--gray-500); }
.track--surveillance { border-left: 4px solid var(--teal); }
.track--palliative { border-left: 4px solid var(--purple-700); }
.track-head {
    display: flex; justify-content: space-between; align-items: baseline;
    margin-bottom: 8px;
}
.track-name { font-family: var(--font-display); font-size: 18px; }
.track-default-badge {
    background: var(--green-100); color: var(--green-700);
    font-size: 10px; padding: 2px 8px; border-radius: 4px;
    font-family: var(--font-mono); text-transform: uppercase;
}
.track dl { font-size: 13px; }
.track dt { font-weight: 700; color: var(--gray-700); margin-top: 8px; }
.track dd { color: var(--gray-700); margin-left: 0; }
.track ul { font-size: 13px; padding-left: 18px; }

/* Tables — workup steps, etc. */
.tbl { width: 100%; border-collapse: collapse; font-size: 13px; }
.tbl th {
    background: var(--green-700); color: white; padding: 8px 10px;
    text-align: left; font-size: 11px; letter-spacing: 0.5px;
    text-transform: uppercase; font-weight: 600;
}
.tbl td {
    padding: 8px 10px; border-bottom: 1px solid var(--gray-100);
    vertical-align: top; color: var(--gray-700);
}
.tbl tr:last-child td { border-bottom: none; }
.tbl tbody tr:nth-child(even) td { background: var(--gray-50); }

/* Badges */
.badge {
    display: inline-block; padding: 2px 7px; border-radius: 4px;
    font-size: 10px; font-weight: 600; font-family: var(--font-mono);
    text-transform: uppercase; letter-spacing: 0.3px;
}
.badge--required { background: var(--red-bg); color: #b91c1c; }
.badge--recommended { background: var(--blue-bg); color: var(--blue-700); }
.badge--optional { background: var(--gray-100); color: var(--gray-700); }
.badge--blocking { background: var(--red-bg); color: #b91c1c; }
.badge--default { background: var(--green-100); color: var(--green-700); }
.badge--lab { background: var(--blue-bg); color: var(--blue-700); }
.badge--imaging { background: var(--purple-bg); color: var(--purple-700); }
.badge--histology { background: var(--amber-bg); color: #92400e; }
.badge--consult { background: var(--gray-100); color: var(--gray-700); }
.badge--other { background: var(--gray-100); color: var(--gray-700); }

/* Lists */
.role-list { list-style: none; padding: 0; }
.role-list li {
    padding: 10px 0; border-bottom: 1px dashed var(--gray-200);
}
.role-list li:last-child { border-bottom: none; }
.role-list .role-name { font-weight: 600; color: var(--gray-900); }
.role-list .role-reason {
    font-size: 13px; color: var(--gray-700); margin-top: 4px;
}
.role-list .role-questions {
    font-size: 12px; color: var(--gray-500); margin-top: 4px;
    font-family: var(--font-mono);
}

.q-list { list-style: none; padding: 0; }
.q-list li {
    padding: 12px 14px; margin-bottom: 8px;
    border-radius: 6px; background: var(--gray-50);
    border-left: 3px solid var(--gray-200);
}
.q-list li.blocking {
    border-left-color: var(--red-alert); background: var(--red-bg);
}
.q-list .q-id {
    font-family: var(--font-mono); font-size: 11px;
    color: var(--gray-500); margin-bottom: 4px;
}
.q-list .q-text { font-size: 14px; color: var(--gray-900); margin-bottom: 4px; }
.q-list .q-rationale { font-size: 12px; color: var(--gray-700); font-style: italic; }
.q-list .q-owner {
    font-family: var(--font-mono); font-size: 11px;
    color: var(--green-700); margin-top: 4px;
}

/* MDT block */
.mdt {
    background: var(--green-50); border-radius: 10px; padding: 18px;
    margin-top: 14px;
}

/* Steps timeline (workup) */
.steps { padding-left: 0; list-style: none; }
.steps li {
    padding: 10px 0 10px 36px; position: relative;
    border-bottom: 1px solid var(--gray-100);
}
.steps li:last-child { border-bottom: none; }
.steps .step-num {
    position: absolute; left: 0; top: 12px; width: 24px; height: 24px;
    background: var(--green-600); color: white; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 11px; font-weight: 700; font-family: var(--font-mono);
}
.steps .step-name { font-weight: 600; color: var(--gray-900); }
.steps .step-rationale { font-size: 12px; color: var(--gray-500); margin-top: 4px; }

/* Sources */
.sources { font-family: var(--font-mono); font-size: 11px; color: var(--gray-500); }
.sources li { padding: 4px 0; }

/* Etiological driver — featured card for etiologically_driven archetype */
.etiology-card {
    background: linear-gradient(135deg, var(--green-50) 0%, white 100%);
    border-left: 4px solid var(--teal); border-radius: 8px;
    padding: 18px 20px; margin-bottom: 22px;
}
.etiology-card .label {
    font-family: var(--font-mono); font-size: 11px; letter-spacing: 1px;
    text-transform: uppercase; color: var(--teal-dark); margin-bottom: 6px;
}
.etiology-card .archetype {
    font-family: var(--font-display); font-size: 18px; color: var(--green-900);
    margin-bottom: 8px;
}
.etiology-card ul { padding-left: 20px; font-size: 14px; color: var(--gray-700); }
.etiology-card ul li { padding: 3px 0; }

/* PRO/CONTRA — two-column grid for red flags */
.pro-contra { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.pc-col { border: 1px solid var(--gray-200); border-radius: 8px; padding: 14px; }
.pc-col--pro { border-left: 4px solid var(--amber-alert); background: var(--amber-bg); }
.pc-col--contra { border-left: 4px solid var(--red-alert); background: var(--red-bg); }
.pc-col h3 { color: var(--gray-900); margin-top: 0; }
.pc-col ul { padding-left: 20px; font-size: 13px; color: var(--gray-700); }
.pc-col li { padding: 4px 0; }
.pc-col .rf-id {
    font-family: var(--font-mono); font-size: 10px; color: var(--gray-500);
    display: block; margin-top: 2px;
}

/* Branch-explanation — actually-fired RFs from the engine trace, with
   the conflict-resolution winner highlighted. Distinct from PRO/CONTRA
   above (which lists possible triggers in the abstract). */
.branch-explanation { margin: 18px 0; }
.branch-explanation .branch-step {
    background: var(--green-bg, #ecfdf5); border-left: 4px solid var(--green-700, #047857);
    padding: 10px 14px; border-radius: 6px; margin-bottom: 10px;
}
.branch-explanation .branch-step-head {
    font-size: 13px; color: var(--gray-700); margin-bottom: 6px; font-weight: 600;
}
.branch-explanation .branch-step ul {
    margin: 0; padding-left: 20px; font-size: 13px; color: var(--gray-700);
}
.branch-explanation .branch-step li { padding: 3px 0; line-height: 1.5; }
.branch-explanation .rf-winner-tag {
    font-family: var(--font-mono); font-size: 9.5px; letter-spacing: 0.5px;
    background: var(--green-700, #047857); color: white;
    padding: 1px 6px; border-radius: 3px; margin-left: 4px; vertical-align: 1px;
}
.branch-explanation .src-chip {
    font-family: var(--font-mono); font-size: 9.5px;
    background: var(--gray-100); color: var(--gray-700);
    padding: 1px 6px; border-radius: 3px; margin-left: 4px;
}

/* Do-not — strongly framed prohibitive list */
.do-not {
    background: var(--red-bg); border-left: 4px solid var(--red-alert);
    border-radius: 6px; padding: 14px 18px; margin-bottom: 12px;
}
.do-not .track-name {
    font-family: var(--font-display); font-size: 15px; color: var(--gray-900);
    margin-bottom: 8px;
}
.do-not ul { padding-left: 20px; font-size: 13px; color: #7f1d1d; }
.do-not li { padding: 3px 0; }

/* Timeline — horizontal phase strip */
.timeline {
    display: flex; gap: 4px; margin-top: 8px;
    overflow-x: auto; padding-bottom: 8px;
}
.tl-phase {
    flex: 1; min-width: 120px;
    background: var(--green-100); border-radius: 6px;
    padding: 10px 12px; border-top: 3px solid var(--green-600);
}
.tl-phase--baseline { border-top-color: var(--teal); background: #ccfbf1; }
.tl-phase--induction { border-top-color: var(--green-600); background: var(--green-100); }
.tl-phase--response { border-top-color: var(--amber-alert); background: var(--amber-bg); }
.tl-phase--maintenance { border-top-color: var(--blue-700); background: var(--blue-bg); }
.tl-phase--followup { border-top-color: var(--gray-500); background: var(--gray-100); }
.tl-phase .name {
    font-weight: 700; font-size: 12px; color: var(--gray-900);
    margin-bottom: 4px;
}
.tl-phase .window {
    font-family: var(--font-mono); font-size: 10px; color: var(--gray-700);
}

/* Footer */
.doc-footer {
    margin-top: 40px; padding-top: 20px;
    border-top: 1px solid var(--gray-200);
    font-size: 11px; color: var(--gray-500); line-height: 1.6;
}
.fda-disclosure {
    background: var(--gray-50); padding: 14px; border-radius: 6px;
    margin-bottom: 14px; font-size: 12px; color: var(--gray-700);
}
.fda-disclosure strong { color: var(--gray-900); }
.version-chain {
    font-family: var(--font-mono); font-size: 11px;
    background: var(--gray-100); padding: 8px 12px; border-radius: 4px;
    margin-bottom: 10px;
}
.medical-disclaimer {
    font-style: italic; color: var(--gray-700); font-size: 11px;
    border-left: 2px solid var(--gray-200); padding-left: 12px;
}

/* Skill metadata badge inline with each role */
.skill-meta {
    font-family: var(--font-mono); font-size: 10px;
    color: var(--gray-500); margin-top: 4px;
    display: flex; flex-wrap: wrap; gap: 10px;
}
.skill-meta .pill {
    padding: 1px 6px; border-radius: 3px; background: var(--gray-100);
}
.skill-meta .pill--reviewed { background: var(--green-100); color: var(--green-700); }
.skill-meta .pill--stub { background: var(--amber-bg); color: var(--amber); }

/* Skill catalog block */
.skill-catalog { margin-top: 18px; }
.skill-catalog table { width: 100%; border-collapse: collapse; font-size: 12px; }
.skill-catalog th {
    text-align: left; padding: 6px 8px; background: var(--gray-100);
    font-family: var(--font-mono); font-size: 10px; letter-spacing: 0.5px;
    text-transform: uppercase; color: var(--gray-700);
}
.skill-catalog td {
    padding: 6px 8px; border-bottom: 1px solid var(--gray-100);
    vertical-align: top;
}
.skill-catalog tr.activated td:first-child::before {
    content: "✓ "; color: var(--green-600); font-weight: 700;
}
.skill-catalog tr.dormant { color: var(--gray-500); }
.skill-catalog tr.dormant td:first-child::before {
    content: "○ "; color: var(--gray-500);
}
.skill-catalog .ver {
    font-family: var(--font-mono); color: var(--gray-700);
}
"""


# ── Helpers ───────────────────────────────────────────────────────────────


def _h(s) -> str:
    """Escape for HTML output."""
    if s is None:
        return ""
    return html.escape(str(s))


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


# ── i18n: live translation client for long free-text ─────────────────────
#
# Phase B of auto-translate render: long free-text from KB (Indication
# notes, do_not_do bullets, RedFlag definitions, MDT role reasons) goes
# through a configured translate client (DeepL Free + LibreTranslate
# fallback + glossary protection + on-disk cache).
#
# Graceful degrade: if neither DEEPL_API_KEY nor LIBRETRANSLATE_URL is
# set in the environment, `_translate_kb_text` returns the original UA
# text unchanged. Render still produces a usable document, just with
# UA-only KB content embedded.
#
# Per CHARTER §8.3 every cached translation is marked
# `machine_translated: true` for clinician review.

_TRANSLATE_CLIENT = None
_TRANSLATE_CLIENT_INIT = False


def _get_translate_client():
    """Lazy-load the translate client once per process. Returns None if
    no upstream is configured — caller falls back to original text."""
    global _TRANSLATE_CLIENT, _TRANSLATE_CLIENT_INIT
    if _TRANSLATE_CLIENT_INIT:
        return _TRANSLATE_CLIENT
    _TRANSLATE_CLIENT_INIT = True
    import os
    if not (os.environ.get("DEEPL_API_KEY") or os.environ.get("LIBRETRANSLATE_URL")):
        _TRANSLATE_CLIENT = None
        return None
    try:
        from knowledge_base.clients.translate_client import build_full_stack
        _TRANSLATE_CLIENT = build_full_stack()
    except Exception:
        _TRANSLATE_CLIENT = None
    return _TRANSLATE_CLIENT


def _set_translate_client(client) -> None:
    """Test hook — inject a stub client. Pass None to clear + force
    re-init from env on next call."""
    global _TRANSLATE_CLIENT, _TRANSLATE_CLIENT_INIT
    _TRANSLATE_CLIENT = client
    _TRANSLATE_CLIENT_INIT = client is not None


def _translate_kb_text(text: str, target_lang: str, source_lang: str = "uk") -> str:
    """Translate a UA free-text fragment to target_lang via the configured
    client. Returns the original text if:
    - target_lang is the source language (no translation needed)
    - text is empty or whitespace-only
    - no translate client configured (graceful degrade)
    - the client raises (network failure, quota, etc.)
    """
    if not text or not text.strip():
        return text
    if target_lang == source_lang or not target_lang:
        return text
    client = _get_translate_client()
    if client is None:
        return text
    try:
        return client.translate(text, target_lang=target_lang, source_lang=source_lang)
    except Exception:
        return text


def _h_t(text, target_lang: str = "uk", source_lang: str = "uk") -> str:
    """HTML-escape AND translate (where applicable). Drop-in replacement
    for `_h(...)` at sites that emit long UA free-text from the KB.
    Translation happens BEFORE escaping — the cached translation is in
    natural language, escape is just transport."""
    if text is None:
        return ""
    return html.escape(_translate_kb_text(str(text), target_lang, source_lang))


# ── i18n: UI label dictionary (UA + EN) ───────────────────────────────────
#
# Used by render to switch static section headers / banners / disclaimers
# between UA and EN. Long free-text from KB is handled by
# `_translate_kb_text` (live translation, configured via env vars).
# For `target_lang` outside {uk, en}, falls back to UA on UI labels;
# free-text still translated by the client if it supports the language.

_UI_STRINGS: dict[str, dict[str, str]] = {
    # Section headers
    "treatment_options":           {"uk": "Варіанти лікування", "en": "Treatment options"},
    "etiological_driver":          {"uk": "Етіологічний драйвер", "en": "Etiological driver"},
    "etiological_driver_label":    {"uk": "Etiological driver · etiologically_driven archetype",
                                    "en": "Etiological driver · etiologically_driven archetype"},
    "pretreatment":                {"uk": "Pre-treatment investigations",
                                    "en": "Pre-treatment investigations"},
    "pretreatment_sub":            {"uk": "Дослідження перед стартом терапії · критичні / стандарт / бажано · поєднані по треках",
                                    "en": "Investigations before treatment start · critical / standard / desired · merged across tracks"},
    "redflags_pro_contra":         {"uk": "Red flags — PRO / CONTRA aggressive",
                                    "en": "Red flags — PRO / CONTRA aggressive"},
    "what_not":                    {"uk": "Що НЕ робити", "en": "What NOT to do"},
    "what_not_sub":                {"uk": "Прямі прохібітивні правила, кожне з обґрунтуванням у regimen / supportive care / contraindication",
                                    "en": "Explicit prohibitive rules, each grounded in a regimen / supportive care / contraindication entity"},
    "monitoring":                  {"uk": "Monitoring schedule", "en": "Monitoring schedule"},
    "monitoring_sub":              {"uk": "Графік моніторингу за фазами лікування",
                                    "en": "Monitoring schedule by treatment phase"},
    "timeline":                    {"uk": "Timeline", "en": "Timeline"},
    "timeline_sub":                {"uk": "Хронологія лікування — derived from regimen + monitoring schedule",
                                    "en": "Treatment timeline — derived from regimen + monitoring schedule"},
    "skills_required":             {"uk": "Скіли (required) — обов'язкові віртуальні спеціалісти",
                                    "en": "Skills (required) — mandatory virtual specialists"},
    "skills_recommended":          {"uk": "Скіли (recommended) — рекомендовані для розгляду",
                                    "en": "Skills (recommended) — for consideration"},
    "skills_optional":             {"uk": "Скіли (optional) — опціональні",
                                    "en": "Skills (optional)"},
    "mdt_brief":                   {"uk": "MDT brief", "en": "MDT brief"},
    "open_questions":              {"uk": "Open questions", "en": "Open questions"},
    "data_quality":                {"uk": "Data quality", "en": "Data quality"},
    "blocking":                    {"uk": "BLOCKING", "en": "BLOCKING"},
    "sources_cited":               {"uk": "Sources cited", "en": "Sources cited"},
    # Track labels (matches plan.py track id semantics)
    "track_standard":              {"uk": "Стандартний план", "en": "Standard plan"},
    "track_aggressive":            {"uk": "Агресивний план", "en": "Aggressive plan"},
    "track_surveillance":          {"uk": "Активне спостереження (watch-and-wait)",
                                    "en": "Active surveillance (watch-and-wait)"},
    "track_palliative":            {"uk": "Паліативний план", "en": "Palliative plan"},
    "track_trial":                 {"uk": "План у рамках клінічного дослідження", "en": "Clinical-trial-only plan"},
    # Document headers
    "doc_label_plan":              {"uk": "OpenOnco · Treatment Plan", "en": "OpenOnco · Treatment Plan"},
    "doc_title_plan_prefix":       {"uk": "План лікування", "en": "Treatment plan"},
    "doc_label_brief":             {"uk": "OpenOnco · Workup Brief · DIAGNOSTIC PHASE",
                                    "en": "OpenOnco · Workup Brief · DIAGNOSTIC PHASE"},
    "doc_title_brief":             {"uk": "Brief підготовки до тумор-борду", "en": "Pre-tumor-board workup brief"},
    "doc_label_revision":          {"uk": "OpenOnco · Revision Note", "en": "OpenOnco · Revision Note"},
    "doc_title_revision":          {"uk": "Перегляд плану", "en": "Plan revision"},
    # Banners and labels
    "diagnostic_banner_strong":    {"uk": "⚠ DIAGNOSTIC PHASE — TREATMENT PLAN NOT YET APPLICABLE",
                                    "en": "⚠ DIAGNOSTIC PHASE — TREATMENT PLAN NOT YET APPLICABLE"},
    "patient_label":               {"uk": "Patient", "en": "Patient"},
    "default_badge":                {"uk": "★ DEFAULT", "en": "★ DEFAULT"},
    "indication_label":            {"uk": "Indication", "en": "Indication"},
    "regimen_label":               {"uk": "Regimen", "en": "Regimen"},
    "supportive_label":            {"uk": "Supportive care", "en": "Supportive care"},
    "ci_label":                    {"uk": "Hard contraindications", "en": "Hard contraindications"},
    "reason_label":                {"uk": "Reason", "en": "Reason"},
    # Skill catalog
    "skill_catalog_prefix":        {"uk": "Skill catalog", "en": "Skill catalog"},
    "skill_catalog_active_in":     {"uk": "активовано в цьому плані", "en": "activated in this plan"},
    "skill_catalog_legend":        {"uk": "Усі зареєстровані віртуальні спеціалісти. ✓ — активовано для цього кейсу; ○ — не активовано (доступні для інших клінічних сценаріїв).",
                                    "en": "All registered virtual specialists. ✓ — activated for this case; ○ — not activated (available for other clinical scenarios)."},
    "th_specialist":               {"uk": "Спеціаліст", "en": "Specialist"},
    "th_skill_id":                 {"uk": "skill_id", "en": "skill_id"},
    "th_version":                  {"uk": "Версія", "en": "Version"},
    "th_last_reviewed":            {"uk": "Last reviewed", "en": "Last reviewed"},
    "th_signoffs":                 {"uk": "Sign-offs", "en": "Sign-offs"},
    "th_domain":                   {"uk": "Domain", "en": "Domain"},
    "th_id":                       {"uk": "ID", "en": "ID"},
    "th_name":                     {"uk": "Назва", "en": "Name"},
    "th_priority":                 {"uk": "Пріоритет", "en": "Priority"},
    "th_category":                 {"uk": "Категорія", "en": "Category"},
    "th_needed_for":               {"uk": "Потрібно для", "en": "Needed for"},
    "th_phase":                    {"uk": "Фаза", "en": "Phase"},
    "th_window":                   {"uk": "Вікно", "en": "Window"},
    "th_tests":                    {"uk": "Тести", "en": "Tests"},
    "th_checkpoints":              {"uk": "Контрольні точки", "en": "Checkpoints"},
    "scope_all_tracks":            {"uk": "усі треки", "en": "all tracks"},
    "scope_desired_prefix":        {"uk": "бажано", "en": "desired"},
    # Priority labels
    "priority_critical":           {"uk": "Критично", "en": "Critical"},
    "priority_standard":           {"uk": "Стандарт", "en": "Standard"},
    "priority_desired":            {"uk": "Бажано", "en": "Desired"},
    "priority_calculation_based":  {"uk": "Розрахунок", "en": "Calculation"},
    # PRO/CONTRA columns
    "pro_aggressive":              {"uk": "PRO-AGGRESSIVE", "en": "PRO-AGGRESSIVE"},
    "pro_aggressive_sub":          {"uk": "Тригери що штовхають до агресивного треку",
                                    "en": "Triggers that push toward the aggressive track"},
    "contra_aggressive":           {"uk": "CONTRA-AGGRESSIVE", "en": "CONTRA-AGGRESSIVE"},
    "contra_aggressive_sub":       {"uk": "Жорсткі протипоказання до ескалації",
                                    "en": "Hard contraindications to escalation"},
    # Timeline phase names
    "tl_baseline":                 {"uk": "Baseline", "en": "Baseline"},
    "tl_induction":                {"uk": "Induction", "en": "Induction"},
    "tl_response":                 {"uk": "Response assessment", "en": "Response assessment"},
    "tl_maintenance":              {"uk": "Maintenance", "en": "Maintenance"},
    "tl_followup":                 {"uk": "Follow-up", "en": "Follow-up"},
    # Disclaimers
    "medical_disclaimer":          {
        "uk": "Цей документ — інформаційний ресурс для підтримки обговорення в "
              "тумор-борді (per CHARTER §11). Не система, що приймає клінічні рішення. "
              "Усі рекомендації потребують перевірки лікуючим лікарем.",
        "en": "This document is an informational resource supporting tumor-board "
              "discussion (per CHARTER §11). It is not a system that makes clinical "
              "decisions. Every recommendation must be verified by the treating physician.",
    },
    "fda_disclosure_label":        {"uk": "Per FDA non-device CDS positioning (CHARTER §15):",
                                    "en": "Per FDA non-device CDS positioning (CHARTER §15):"},
}


def _t(key: str, target_lang: str = "uk") -> str:
    """Look up a UI label in the desired language. Falls back to UA if
    the key is missing in the target language. Falls back to the key
    itself if the key is missing entirely (defensive — surfaces missing
    translations clearly in the rendered output)."""
    entry = _UI_STRINGS.get(key)
    if entry is None:
        return key
    return entry.get(target_lang) or entry.get("uk") or key


def _track_label(track_id: str, target_lang: str = "uk") -> str:
    """Map a track_id to its localized display label."""
    return _t(f"track_{track_id}", target_lang) or track_id


def _localize_html(html_text: str, target_lang: str) -> str:
    """Post-process a fully-rendered UA HTML document into another language
    by targeted UI-label substitution. The render layer always produces UA
    first; if the caller asks for `target_lang != "uk"`, we do longest-first
    string replacements over the known UI labels in `_UI_STRINGS` plus a
    handful of common phrases used inside f-strings.

    Free-text KB content (Indication.rationale, Indication.notes, RedFlag
    definitions, etc.) is NOT translated here — that's the next iteration
    via `knowledge_base.clients.translate_client`. Only UI labels.

    Also flips `<html lang="uk">` to `<html lang="en">` for proper a11y.
    """
    if target_lang == "uk" or not target_lang:
        return html_text

    # Build the substitution map: UA-side string → target-lang string, only
    # when both sides exist and differ. Include both the raw and the
    # HTML-escaped form (the render layer pipes most strings through _h()
    # which encodes apostrophes as `&#x27;` etc.) — without the escaped
    # variant a UA literal like "обов'язкові" would never match. Longest-
    # first to avoid collisions ("Стандартний план" before "Стандарт").
    pairs: list[tuple[str, str]] = []
    seen: set[str] = set()
    for entry in _UI_STRINGS.values():
        ua = entry.get("uk")
        out = entry.get(target_lang)
        if not ua or not out or ua == out:
            continue
        for src, dst in (
            (ua, out),
            (html.escape(ua, quote=True), html.escape(out, quote=True)),
        ):
            if src in seen or src == dst:
                continue
            pairs.append((src, dst))
            seen.add(src)
    pairs.sort(key=lambda p: len(p[0]), reverse=True)

    out_html = html_text
    for src, dst in pairs:
        out_html = out_html.replace(src, dst)

    # Doc-language attribute
    out_html = out_html.replace('<html lang="uk">', f'<html lang="{target_lang}">')
    return out_html


def _doc_shell(title: str, body: str, target_lang: str = "uk") -> str:
    """Wrap rendered body in a complete HTML document with embedded CSS."""
    lang_attr = "en" if target_lang == "en" else "uk"
    return (
        "<!DOCTYPE html>\n"
        f'<html lang="{lang_attr}">\n<head>\n'
        '<meta charset="UTF-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
        f"<title>{_h(title)}</title>\n"
        '<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900'
        '&family=Source+Sans+3:wght@300;400;500;600;700'
        '&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">\n'
        f"<style>{_CSS}</style>\n"
        "</head>\n<body>\n"
        f'<div class="page">{body}</div>\n'
        "</body>\n</html>\n"
    )


def _render_mdt_section(mdt: Optional[MDTOrchestrationResult],
                        target_lang: str = "uk") -> str:
    if mdt is None:
        return ""
    parts: list[str] = []

    def _skill_meta_html(r) -> str:
        """One-line metadata strip showing skill version + last-reviewed
        date + sign-off status — so a clinician verifying changes can see
        at a glance which version of which skill produced this row."""
        s = r.skill
        if s is None:
            return ""
        status_cls = "pill--reviewed" if s.review_status == "reviewed" else "pill--stub"
        status_label = "REVIEWED" if s.review_status == "reviewed" else "STUB"
        lead = _h(s.clinical_lead) if s.clinical_lead else "TBD"
        return (
            '<div class="skill-meta">'
            f'<span class="pill">skill: <code>{_h(s.skill_id)}</code></span>'
            f'<span class="pill">v{_h(s.version)}</span>'
            f'<span class="pill">reviewed {_h(s.last_reviewed)}</span>'
            f'<span class="pill {status_cls}">{status_label}</span>'
            f'<span class="pill">sign-offs: {s.signoffs}</span>'
            f'<span class="pill">lead: {lead}</span>'
            "</div>"
        )

    def _role_block(label: str, badge_cls: str, roles) -> str:
        if not roles:
            return ""
        items = []
        for r in roles:
            qs = (
                f'<div class="role-questions">Owns: {_h(", ".join(r.linked_questions))}</div>'
                if r.linked_questions else ""
            )
            items.append(
                f"<li>"
                f'<span class="role-name">{_h(r.role_name)}</span> '
                f'<span class="badge {badge_cls}">{_h(r.priority)}</span>'
                f'<div class="role-reason">{_h_t(r.reason, target_lang)}</div>'
                f"{qs}"
                f"{_skill_meta_html(r)}"
                f"</li>"
            )
        return (
            f"<h3>{_h(label)} ({len(roles)})</h3>"
            f'<ul class="role-list">{"".join(items)}</ul>'
        )

    parts.append(_role_block(
        "Скіли (required) — обов'язкові віртуальні спеціалісти",
        "badge--required", mdt.required_roles))
    parts.append(_role_block(
        "Скіли (recommended) — рекомендовані для розгляду",
        "badge--recommended", mdt.recommended_roles))
    parts.append(_role_block(
        "Скіли (optional) — опціональні",
        "badge--optional", mdt.optional_roles))

    qs = mdt.open_questions
    if qs:
        blocking = sum(1 for q in qs if q.blocking)
        items = []
        for q in qs:
            cls = " blocking" if q.blocking else ""
            tag = '<span class="badge badge--blocking">BLOCKING</span> ' if q.blocking else ""
            items.append(
                f'<li class="{cls.strip()}">'
                f'<div class="q-id">{tag}{_h(q.id)}</div>'
                f'<div class="q-text">{_h_t(q.question, target_lang)}</div>'
                f'<div class="q-rationale">{_h_t(q.rationale, target_lang)}</div>'
                f'<div class="q-owner">→ {_h(q.owner_role)}</div>'
                f"</li>"
            )
        parts.append(
            f"<h3>Open questions ({len(qs)}, {blocking} blocking)</h3>"
            f'<ul class="q-list">{"".join(items)}</ul>'
        )

    dq = mdt.data_quality_summary or {}
    crit = dq.get("missing_critical_fields") or []
    rec = dq.get("missing_recommended_fields") or []
    unevaluated = dq.get("unevaluated_red_flags") or []
    if crit or rec or unevaluated:
        parts.append("<h3>Data quality</h3><ul>")
        if crit:
            parts.append(f"<li>Missing critical: {_h(', '.join(crit))}</li>")
        if rec:
            parts.append(f"<li>Missing recommended: {_h(', '.join(rec))}</li>")
        if unevaluated:
            parts.append(f"<li>Unevaluated RedFlags: {_h(', '.join(unevaluated))}</li>")
        parts.append("</ul>")

    # Skill catalog — full list of registered skills with activation marker
    activated_ids = {s.skill_id for s in mdt.activated_skills}
    catalog_rows = []
    # Pull the full registry via the dict surfaced through to_dict()
    full = mdt.to_dict().get("skill_catalog", [])
    for s in full:
        sid = s["skill_id"]
        is_active = sid in activated_ids
        cls = "activated" if is_active else "dormant"
        catalog_rows.append(
            f'<tr class="{cls}">'
            f'<td>{_h(s["name"])}</td>'
            f'<td><code>{_h(sid)}</code></td>'
            f'<td class="ver">v{_h(s["version"])}</td>'
            f'<td>{_h(s["last_reviewed"])}</td>'
            f'<td>{s["signoffs"]}</td>'
            f'<td>{_h(s.get("domain") or "—")}</td>'
            "</tr>"
        )
    parts.append(
        '<div class="skill-catalog">'
        f'<h3>Skill catalog ({len(activated_ids)}/{len(full)} активовано в цьому плані)</h3>'
        '<div class="section-sub">Усі зареєстровані віртуальні спеціалісти. '
        '✓ — активовано для цього кейсу; ○ — не активовано (доступні для інших клінічних сценаріїв).</div>'
        '<table><thead><tr>'
        '<th>Спеціаліст</th><th>skill_id</th><th>Версія</th>'
        '<th>Last reviewed</th><th>Sign-offs</th><th>Domain</th>'
        "</tr></thead><tbody>"
        f'{"".join(catalog_rows)}'
        "</tbody></table>"
        "</div>"
    )

    return f'<section><h2>MDT brief</h2><div class="mdt">{"".join(parts)}</div></section>'


def _render_fda_disclosure(text: str) -> str:
    return (
        f'<div class="fda-disclosure">'
        f"<strong>Per FDA non-device CDS positioning (CHARTER §15):</strong> "
        f"{_h(text)}"
        f"</div>"
    )


def _render_version_chain(plan_id, version, supersedes, superseded_by, generated_at) -> str:
    parts = [f"plan_id: {_h(plan_id)} | version: {_h(version)} | generated: {_h(generated_at)}"]
    if supersedes:
        parts.append(f"supersedes: {_h(supersedes)}")
    if superseded_by:
        parts.append(f"superseded_by: {_h(superseded_by)}")
    return f'<div class="version-chain">{" | ".join(parts)}</div>'


_MEDICAL_DISCLAIMER = (
    "Цей документ — інформаційний ресурс для підтримки обговорення в "
    "тумор-борді (per CHARTER §11). Не система, що приймає клінічні рішення. "
    "Усі рекомендації потребують перевірки лікуючим лікарем."
)


# ── Section helpers (treatment Plan) ──────────────────────────────────────


def _render_etiological_driver(disease: Optional[dict]) -> str:
    """Etiologically-driven archetype gets a featured card explaining WHY
    a particular driver (HCV, H. pylori, EBV, etc.) shapes treatment.
    Returns empty string for non-etiologically_driven diseases."""
    if not disease:
        return ""
    archetype = disease.get("archetype")
    if archetype != "etiologically_driven":
        return ""
    factors = disease.get("etiological_factors") or []
    name = (disease.get("names") or {}).get("ukrainian") or (
        disease.get("names") or {}).get("preferred") or disease.get("id", "")
    factor_items = "".join(f"<li>{_h(f)}</li>" for f in factors) or "<li>—</li>"
    return (
        '<section>'
        '<h2>Етіологічний драйвер</h2>'
        '<div class="etiology-card">'
        '<div class="label">Etiological driver · etiologically_driven archetype</div>'
        f'<div class="archetype">{_h(name)}</div>'
        f'<ul>{factor_items}</ul>'
        '</div>'
        '</section>'
    )


_PRIORITY_LABEL_UA = {
    "critical": "Критично",
    "standard": "Стандарт",
    "desired": "Бажано",
    "calculation_based": "Розрахунок",
}
_PRIORITY_BADGE_CLS = {
    "critical": "badge--required",
    "standard": "badge--recommended",
    "desired": "badge--optional",
    "calculation_based": "badge--optional",
}
_PRIORITY_RANK = {"critical": 0, "standard": 1, "desired": 2, "calculation_based": 3}


def _render_pretreatment_investigations(plan, kb_resolved: dict) -> str:
    """Pre-treatment investigations table: union of required + desired tests
    across all tracks, sorted by priority_class. Each row shows test name,
    priority badge, category, and which tracks need it.
    Per REFERENCE_CASE_SPECIFICATION §3.5."""
    tests_lookup = (kb_resolved or {}).get("tests") or {}
    if not tests_lookup:
        return ""

    # Collect: test_id → {required_by: set[track_id], desired_by: set[track_id]}
    test_use: dict[str, dict] = {}
    for t in plan.tracks:
        ind = t.indication_data or {}
        for tid in ind.get("required_tests") or []:
            test_use.setdefault(tid, {"required_by": set(), "desired_by": set()})
            test_use[tid]["required_by"].add(t.track_id)
        for tid in ind.get("desired_tests") or []:
            test_use.setdefault(tid, {"required_by": set(), "desired_by": set()})
            test_use[tid]["desired_by"].add(t.track_id)
    if not test_use:
        return ""

    rows = []
    for tid, use in sorted(
        test_use.items(),
        key=lambda kv: (
            _PRIORITY_RANK.get((tests_lookup.get(kv[0]) or {}).get("priority_class", "standard"), 1),
            kv[0],
        ),
    ):
        test = tests_lookup.get(tid) or {}
        names = test.get("names") or {}
        name = names.get("ukrainian") or names.get("preferred") or tid
        priority = test.get("priority_class") or "standard"
        category = test.get("category") or "—"
        # If required by every track → "all"; else list which tracks
        all_track_ids = {t.track_id for t in plan.tracks}
        if use["required_by"] == all_track_ids:
            scope = "усі треки"
        elif use["required_by"]:
            scope = ", ".join(sorted(use["required_by"]))
        else:
            scope = "бажано (" + ", ".join(sorted(use["desired_by"])) + ")"
        priority_badge = (
            f'<span class="badge {_PRIORITY_BADGE_CLS.get(priority, "badge--optional")}">'
            f'{_h(_PRIORITY_LABEL_UA.get(priority, priority))}</span>'
        )
        rows.append(
            f'<tr><td>{_h(tid)}</td><td>{_h(name)}</td>'
            f'<td>{priority_badge}</td>'
            f'<td>{_h(category)}</td><td>{_h(scope)}</td></tr>'
        )

    return (
        '<section>'
        '<h2>Pre-treatment investigations</h2>'
        '<div class="section-sub">Дослідження перед стартом терапії · '
        'критичні / стандарт / бажано · поєднані по треках</div>'
        '<table class="tbl">'
        '<thead><tr><th>ID</th><th>Назва</th><th>Пріоритет</th>'
        '<th>Категорія</th><th>Потрібно для</th></tr></thead>'
        f'<tbody>{"".join(rows)}</tbody>'
        '</table>'
        '</section>'
    )


def _render_branch_explanation(
    plan_result, kb_resolved: dict, target_lang: str = "uk"
) -> str:
    """Surface the actually-fired RedFlags from the engine trace.

    For each step that resolved a branch (`outcome=True` and `result` set),
    list the RFs that fired in that step and which one won the conflict-
    resolution tiebreak (`winner_red_flag` set by walk_algorithm in P2).

    This is the "Why this branch was chosen" answer — distinct from the
    PRO/CONTRA section above, which lists *possible* triggers. This one
    lists what actually drove the chosen branch on this specific patient.
    """
    rf_lookup = (kb_resolved or {}).get("red_flags") or {}
    src_lookup = (kb_resolved or {}).get("sources") or {}
    trace = getattr(plan_result, "trace", None) or []

    explained_steps: list[str] = []
    for step in trace:
        fired = step.get("fired_red_flags") or []
        if not fired:
            continue
        winner = step.get("winner_red_flag")
        branch = step.get("branch") or {}
        step_id = step.get("step")
        result_target = branch.get("result") or branch.get("next_step")

        rf_items: list[str] = []
        for rid in fired:
            rf = rf_lookup.get(rid) or {}
            defn = (
                rf.get("definition_ua")
                if target_lang == "uk" and rf.get("definition_ua")
                else rf.get("definition") or "—"
            )
            srcs = rf.get("sources") or []
            src_chips = "".join(
                f'<span class="src-chip">{_h(sid)}</span>'
                for sid in srcs
            )
            winner_mark = (
                ' <span class="rf-winner-tag">★ winner</span>'
                if rid == winner else ""
            )
            rf_items.append(
                f'<li><strong>{_h(rid)}</strong>{winner_mark}: '
                f'{_h(defn)} {src_chips}</li>'
            )

        head = (
            f"Step {step_id} → branch <code>{_h(str(result_target))}</code>"
            if result_target
            else f"Step {step_id}"
        )
        explained_steps.append(
            f'<div class="branch-step">'
            f'<div class="branch-step-head">{head}</div>'
            f'<ul>{"".join(rf_items)}</ul>'
            f'</div>'
        )

    if not explained_steps:
        return ""

    title = "Чому обрано саме цей трек" if target_lang == "uk" else "Why this branch was chosen"
    sub = (
        "Тригери з профілю пацієнта, що активувалися та визначили вибір."
        if target_lang == "uk"
        else "Triggers from the patient profile that fired and drove the chosen branch."
    )
    return (
        '<section class="branch-explanation">'
        f'<h2>{title}</h2>'
        f'<div class="section-sub">{sub}</div>'
        f'{"".join(explained_steps)}'
        '</section>'
    )


def _render_red_flags_pro_contra(plan, kb_resolved: dict, target_lang: str = "uk") -> str:
    """RedFlag PRO/CONTRA categorization for the aggressive escalation:

    - PRO-AGGRESSIVE: red flags that, when present, push the engine toward
      the aggressive track. Source: indication.red_flags_triggering_alternative
      on the STANDARD track + algorithm.decision_tree any_of red_flag clauses
      that resolve to the aggressive indication.
    - CONTRA-AGGRESSIVE: hard contraindications attached to the AGGRESSIVE
      track's indication / regimen — reasons NOT to escalate.

    Per REFERENCE_CASE_SPECIFICATION §3.8.
    """
    rf_lookup = (kb_resolved or {}).get("red_flags") or {}
    if not plan.tracks:
        return ""

    # PRO: union of red_flags_triggering_alternative across non-aggressive tracks
    pro_ids: set[str] = set()
    for t in plan.tracks:
        if t.track_id == "aggressive":
            continue
        ind = t.indication_data or {}
        pro_ids.update(ind.get("red_flags_triggering_alternative") or [])
    # Also pick up red flags from algorithm decision tree pointing to aggressive
    algo = (kb_resolved or {}).get("algorithm") or {}
    aggr_ind_ids = {
        t.indication_id for t in plan.tracks if t.track_id == "aggressive"
    }
    for step in algo.get("decision_tree") or []:
        if_true = (step.get("if_true") or {}).get("result")
        if if_true in aggr_ind_ids:
            ev = step.get("evaluate") or {}
            for clause in (ev.get("any_of") or []) + (ev.get("all_of") or []):
                if isinstance(clause, dict) and clause.get("red_flag"):
                    pro_ids.add(clause["red_flag"])

    # CONTRA: hard contraindications on aggressive track
    contra_items: list[dict] = []
    for t in plan.tracks:
        if t.track_id != "aggressive":
            continue
        for c in t.contraindications_data or []:
            contra_items.append(c)

    if not pro_ids and not contra_items:
        return ""

    def _rf_li(rid: str) -> str:
        rf = rf_lookup.get(rid) or {}
        # Prefer the bilingual EN field if target_lang=en — saves a translate
        # call when curator already provided an English definition. Fall back
        # to translating the UA field if only UA is present.
        if target_lang == "en" and rf.get("definition"):
            defn = rf["definition"]
            return f'<li>{_h(defn)}<span class="rf-id">{_h(rid)}</span></li>'
        defn = rf.get("definition_ua") or rf.get("definition") or "—"
        return f'<li>{_h_t(defn, target_lang)}<span class="rf-id">{_h(rid)}</span></li>'

    def _ci_li(c: dict) -> str:
        cid = c.get("id", "?")
        if target_lang == "en" and c.get("description"):
            descr = c["description"]
            return f'<li>{_h(descr)}<span class="rf-id">{_h(cid)}</span></li>'
        descr = c.get("description_ua") or c.get("description") or "—"
        return f'<li>{_h_t(descr, target_lang)}<span class="rf-id">{_h(cid)}</span></li>'

    pro_html = (
        '<div class="pc-col pc-col--pro">'
        '<h3>PRO-AGGRESSIVE</h3>'
        '<div class="section-sub">Тригери що штовхають до агресивного треку</div>'
        f'<ul>{"".join(_rf_li(r) for r in sorted(pro_ids)) or "<li>—</li>"}</ul>'
        '</div>'
    )
    contra_html = (
        '<div class="pc-col pc-col--contra">'
        '<h3>CONTRA-AGGRESSIVE</h3>'
        '<div class="section-sub">Жорсткі протипоказання до ескалації</div>'
        f'<ul>{"".join(_ci_li(c) for c in contra_items) or "<li>—</li>"}</ul>'
        '</div>'
    )
    return (
        '<section>'
        '<h2>Red flags — PRO / CONTRA aggressive</h2>'
        f'<div class="pro-contra">{pro_html}{contra_html}</div>'
        '</section>'
    )


def _render_what_not_to_do(plan, target_lang: str = "uk") -> str:
    """Explicitly prohibitive 'do_not_do' list per track.
    Per REFERENCE_CASE_SPECIFICATION §1.3 critical.

    Each bullet is UA free-text from Indication.do_not_do — translated
    via the configured client when target_lang != source."""
    blocks = []
    for t in plan.tracks:
        ind = t.indication_data or {}
        items = ind.get("do_not_do") or []
        if not items:
            continue
        li = "".join(f"<li>{_h_t(x, target_lang)}</li>" for x in items)
        blocks.append(
            '<div class="do-not">'
            f'<div class="track-name">{_h(t.label)} ({_h(t.indication_id)})</div>'
            f'<ul>{li}</ul>'
            '</div>'
        )
    if not blocks:
        return ""
    return (
        '<section>'
        '<h2>Що НЕ робити</h2>'
        '<div class="section-sub">Прямі прохібітивні правила, кожне з обґрунтуванням у regimen / supportive care / contraindication</div>'
        f'{"".join(blocks)}'
        '</section>'
    )


def _render_monitoring_phases(plan) -> str:
    """Monitoring schedule phases as a per-track table.
    Per REFERENCE_CASE_SPECIFICATION §1.3 critical."""
    blocks = []
    seen_monitoring_ids: set[str] = set()
    for t in plan.tracks:
        mon = t.monitoring_data
        if not mon:
            continue
        mid = mon.get("id") or ""
        if mid in seen_monitoring_ids:
            continue  # dedupe — both tracks may share the same monitoring schedule
        seen_monitoring_ids.add(mid)
        phases = mon.get("phases") or []
        if not phases:
            continue
        rows = []
        for ph in phases:
            tests = ", ".join(ph.get("tests") or []) or "—"
            checks = ph.get("checkpoints") or []
            checks_html = (
                "<ul style='padding-left:16px;margin:0;'>"
                + "".join(f"<li>{_h(c)}</li>" for c in checks)
                + "</ul>"
            ) if checks else "—"
            rows.append(
                f'<tr><td><strong>{_h(ph.get("name", "?"))}</strong></td>'
                f'<td>{_h(ph.get("window", "—"))}</td>'
                f'<td style="font-family:var(--font-mono);font-size:11px;">{_h(tests)}</td>'
                f'<td>{checks_html}</td></tr>'
            )
        blocks.append(
            f'<h3>{_h(t.label)} · {_h(mid)}</h3>'
            '<table class="tbl">'
            '<thead><tr><th>Фаза</th><th>Вікно</th>'
            '<th>Тести</th><th>Контрольні точки</th></tr></thead>'
            f'<tbody>{"".join(rows)}</tbody>'
            '</table>'
        )
    if not blocks:
        return ""
    return (
        '<section>'
        '<h2>Monitoring schedule</h2>'
        '<div class="section-sub">Графік моніторингу за фазами лікування</div>'
        f'{"".join(blocks)}'
        '</section>'
    )


def _render_timeline(plan) -> str:
    """Horizontal timeline strip composed from Regimen.cycle_length_days +
    total_cycles + MonitoringSchedule.phases. CSS-only, no SVG/JS.
    Per REFERENCE_CASE_SPECIFICATION §1.3 should-have."""
    if not plan.tracks:
        return ""

    blocks = []
    seen: set[tuple] = set()
    for t in plan.tracks:
        reg = t.regimen_data or {}
        mon = t.monitoring_data or {}
        key = (reg.get("id"), mon.get("id"))
        if key in seen or key == (None, None):
            continue
        seen.add(key)

        phases_html: list[str] = []

        # Baseline phase from monitoring (always first if present)
        mon_phases = mon.get("phases") or []
        baseline = next((p for p in mon_phases if p.get("name") == "baseline"), None)
        if baseline:
            phases_html.append(
                '<div class="tl-phase tl-phase--baseline">'
                '<div class="name">Baseline</div>'
                f'<div class="window">{_h(baseline.get("window", "—"))}</div>'
                '</div>'
            )

        # Induction phase from regimen cycle metadata
        cycle_len = reg.get("cycle_length_days")
        total_cycles = reg.get("total_cycles") or "—"
        if cycle_len:
            cycles_str = str(total_cycles).strip()
            window = (
                f"{cycle_len}-day cycles × {cycles_str}"
                if cycles_str and cycles_str != "—"
                else f"{cycle_len}-day cycles"
            )
            phases_html.append(
                '<div class="tl-phase tl-phase--induction">'
                f'<div class="name">Induction · {_h(reg.get("name", "—")[:30])}</div>'
                f'<div class="window">{_h(window)}</div>'
                '</div>'
            )

        # Response assessment phase from monitoring
        ra = next((p for p in mon_phases if "response" in (p.get("name", "").lower())), None)
        if ra:
            phases_html.append(
                '<div class="tl-phase tl-phase--response">'
                '<div class="name">Response assessment</div>'
                f'<div class="window">{_h(ra.get("window", "—"))}</div>'
                '</div>'
            )

        # Maintenance phase if present
        maint = next((p for p in mon_phases if "maint" in (p.get("name", "").lower())), None)
        if maint:
            phases_html.append(
                '<div class="tl-phase tl-phase--maintenance">'
                '<div class="name">Maintenance</div>'
                f'<div class="window">{_h(maint.get("window", "—"))}</div>'
                '</div>'
            )

        # Follow-up phase if present
        fu = next(
            (p for p in mon_phases if "follow" in (p.get("name", "").lower())),
            None,
        )
        if fu:
            phases_html.append(
                '<div class="tl-phase tl-phase--followup">'
                '<div class="name">Follow-up</div>'
                f'<div class="window">{_h(fu.get("window", "—"))}</div>'
                '</div>'
            )

        if phases_html:
            blocks.append(
                f'<h3>{_h(t.label)}</h3>'
                f'<div class="timeline">{"".join(phases_html)}</div>'
            )

    if not blocks:
        return ""
    return (
        '<section>'
        '<h2>Timeline</h2>'
        '<div class="section-sub">Хронологія лікування — derived from regimen + monitoring schedule</div>'
        f'{"".join(blocks)}'
        '</section>'
    )


# ── Treatment Plan render ─────────────────────────────────────────────────


def render_plan_html(
    plan_result: PlanResult,
    mdt: Optional[MDTOrchestrationResult] = None,
    *,
    target_lang: str = "uk",
) -> str:
    plan = plan_result.plan
    if plan is None:
        return _doc_shell("OpenOnco — empty plan", "<p>Empty PlanResult; nothing to render.</p>")

    fda = plan.fda_compliance

    # Header
    body: list[str] = []
    body.append(
        '<div class="doc-header">'
        '<div class="doc-label">OpenOnco · Treatment Plan</div>'
        f'<div class="doc-title">План лікування — {_h(plan_result.disease_id)}</div>'
        f'<div class="doc-sub">{_h(plan.id)} · v{_h(plan.version)} · {_h(plan.generated_at[:10])}</div>'
        '</div>'
    )

    # Patient strip
    body.append(
        '<div class="patient-strip">'
        '<div class="label">Patient</div>'
        f'<div class="value">{_h(plan.patient_id)} · Algorithm: {_h(plan_result.algorithm_id)}</div>'
        '</div>'
    )

    # Etiological driver — only for etiologically_driven archetype
    body.append(_render_etiological_driver(
        (plan_result.kb_resolved or {}).get("disease")
    ))

    # Tracks
    track_html = []
    for t in plan.tracks:
        track_class = f"track track--{(t.track_id or 'standard')}"
        if t.is_default:
            badge = '<span class="track-default-badge">★ DEFAULT</span>'
        else:
            badge = ""
        regimen_str = (t.regimen_data or {}).get("name", "—") if t.regimen_data else "—"
        sup = (
            f'<dt>Supportive care</dt><dd>{_h(", ".join(s.get("id", "?") for s in t.supportive_care_data))}</dd>'
            if t.supportive_care_data else ""
        )
        ci = (
            f'<dt>Hard contraindications</dt><dd>{_h(", ".join(c.get("id", "?") for c in t.contraindications_data))}</dd>'
            if t.contraindications_data else ""
        )
        track_html.append(
            f'<div class="{track_class}">'
            f'<div class="track-head"><div class="track-name">{_h(t.label)}</div>{badge}</div>'
            f'<dl>'
            f'<dt>Indication</dt><dd>{_h(t.indication_id)}</dd>'
            f'<dt>Regimen</dt><dd>{_h(regimen_str)}</dd>'
            f'{sup}'
            f'{ci}'
            f'<dt>Reason</dt><dd>{_h(t.selection_reason)}</dd>'
            f'</dl>'
            f'</div>'
        )
    body.append(
        f'<section><h2>Treatment options ({len(plan.tracks)} tracks)</h2>'
        f'<div class="tracks">{"".join(track_html)}</div></section>'
    )

    # Why this branch was chosen — actual fired RFs from the trace,
    # with the conflict-resolution winner tagged. Distinct from the
    # PRO/CONTRA section, which lists possible triggers in the abstract.
    body.append(_render_branch_explanation(plan_result, plan_result.kb_resolved, target_lang))

    # Pre-treatment investigations · RedFlag PRO/CONTRA · What NOT to do ·
    # Monitoring phases · Timeline (REFERENCE_CASE_SPECIFICATION §1.3)
    body.append(_render_pretreatment_investigations(plan, plan_result.kb_resolved))
    body.append(_render_red_flags_pro_contra(plan, plan_result.kb_resolved, target_lang))
    body.append(_render_what_not_to_do(plan, target_lang))
    body.append(_render_monitoring_phases(plan))
    body.append(_render_timeline(plan))

    # MDT brief inline
    body.append(_render_mdt_section(mdt, target_lang))

    # Sources
    if fda.data_sources_summary:
        items = "".join(f"<li>{_h(s)}</li>" for s in fda.data_sources_summary)
        body.append(f"<section><h2>Sources cited</h2><ul class='sources'>{items}</ul></section>")

    # Footer
    body.append('<div class="doc-footer">')
    body.append(_render_version_chain(
        plan.id, plan.version, plan.supersedes, plan.superseded_by, plan.generated_at,
    ))
    body.append(_render_fda_disclosure(fda.intended_use))
    if fda.automation_bias_warning:
        body.append(_render_fda_disclosure(fda.automation_bias_warning))
    body.append(f'<div class="medical-disclaimer">{_h(_MEDICAL_DISCLAIMER)}</div>')
    body.append('</div>')

    out = _doc_shell(f"План лікування — {plan_result.disease_id}", "".join(body))
    return _localize_html(out, target_lang)


# ── Diagnostic Brief render ───────────────────────────────────────────────


def render_diagnostic_brief_html(
    diag_result: DiagnosticPlanResult,
    mdt: Optional[MDTOrchestrationResult] = None,
    *,
    target_lang: str = "uk",
) -> str:
    dp = diag_result.diagnostic_plan
    if dp is None:
        return _doc_shell("OpenOnco — empty diagnostic brief", "<p>Empty DiagnosticPlanResult.</p>")

    body: list[str] = []

    # Header
    body.append(
        '<div class="doc-header">'
        '<div class="doc-label">OpenOnco · Workup Brief · DIAGNOSTIC PHASE</div>'
        '<div class="doc-title">Brief підготовки до тумор-борду</div>'
        f'<div class="doc-sub">{_h(dp.id)} · v{_h(dp.version)} · {_h(dp.generated_at[:10])}</div>'
        '</div>'
    )

    # MANDATORY diagnostic banner (CHARTER §15.2 C7)
    body.append(
        '<div class="banner banner--diagnostic">'
        '<strong>⚠ DIAGNOSTIC PHASE — TREATMENT PLAN NOT YET APPLICABLE</strong>'
        f'{_h(_DIAGNOSTIC_BANNER)}'
        '</div>'
    )

    # Patient + suspicion strip
    susp = diag_result.suspicion or dp.suspicion_snapshot
    susp_html = ""
    if susp:
        tissues = ", ".join(susp.tissue_locations) if susp.tissue_locations else "—"
        hyps = ", ".join(susp.working_hypotheses) if susp.working_hypotheses else "—"
        susp_html = (
            '<div class="patient-strip">'
            '<div class="label">Patient</div>'
            f'<div class="value">{_h(dp.patient_id)} · suspicion lineage: {_h(susp.lineage_hint)}</div>'
            f'<div class="value" style="margin-top:6px;font-size:13px;color:var(--gray-700);">'
            f'Tissues: {_h(tissues)} · Hypotheses: {_h(hyps)}</div>'
        )
        if susp.presentation:
            susp_html += f'<div class="value" style="margin-top:6px;font-size:13px;color:var(--gray-700);">{_h(susp.presentation)}</div>'
        susp_html += "</div>"
    body.append(susp_html)

    # Matched workup
    body.append(
        f'<div class="banner banner--info">'
        f'<strong>Matched workup:</strong> {_h(diag_result.matched_workup_id)} · '
        f'<strong>Очікуваний термін:</strong> ~{_h(dp.expected_timeline_days)} днів'
        '</div>'
    )

    # Workup steps
    steps_html = []
    for s in dp.workup_steps:
        cat_badge = f'<span class="badge badge--{_h(s.category)}">{_h(s.category)}</span> '
        descr = s.description or s.test_id or "?"
        rationale = (
            f'<div class="step-rationale">{_h(s.rationale)}</div>' if s.rationale else ""
        )
        biopsy = ""
        if s.biopsy_approach:
            biopsy = (
                f'<div class="step-rationale" style="margin-top:6px;">'
                f'<strong>Biopsy preferred:</strong> {_h(s.biopsy_approach.preferred)}'
                f'</div>'
            )
        ihc = ""
        if s.ihc_panel and s.ihc_panel.baseline:
            ihc = (
                f'<div class="step-rationale" style="margin-top:4px;">'
                f'<strong>IHC baseline:</strong> {_h(", ".join(s.ihc_panel.baseline))}'
                f'</div>'
            )
        steps_html.append(
            f'<li>'
            f'<span class="step-num">{_h(s.step)}</span>'
            f'<span class="step-name">{cat_badge}{_h(descr)}</span>'
            f'{rationale}'
            f'{biopsy}'
            f'{ihc}'
            f'</li>'
        )
    body.append(
        f'<section><h2>Workup steps ({len(dp.workup_steps)})</h2>'
        f'<ul class="steps">{"".join(steps_html)}</ul></section>'
    )

    # Mandatory questions
    if dp.mandatory_questions:
        items = "".join(f"<li>{_h(q)}</li>" for q in dp.mandatory_questions)
        body.append(
            f'<section><h2>Питання що мають бути закриті ({len(dp.mandatory_questions)})</h2>'
            f'<ul style="padding-left:20px;font-size:14px;line-height:1.7;color:var(--gray-700);">{items}</ul></section>'
        )

    # MDT brief
    body.append(_render_mdt_section(mdt, target_lang))

    # Footer
    body.append('<div class="doc-footer">')
    body.append(_render_version_chain(
        dp.id, dp.version, dp.supersedes, dp.superseded_by, dp.generated_at,
    ))
    body.append(_render_fda_disclosure(dp.intended_use))
    body.append(_render_fda_disclosure(dp.automation_bias_warning))
    body.append(f'<div class="medical-disclaimer">{_h(_MEDICAL_DISCLAIMER)}</div>')
    body.append('</div>')

    out = _doc_shell("OpenOnco · Workup Brief", "".join(body))
    return _localize_html(out, target_lang)


# ── Revision Note render ──────────────────────────────────────────────────


def render_revision_note_html(
    previous: Union[PlanResult, DiagnosticPlanResult],
    new_result: Union[PlanResult, DiagnosticPlanResult],
    transition: str,
    mdt: Optional[MDTOrchestrationResult] = None,
    *,
    target_lang: str = "uk",
) -> str:
    """Renders a revision note: shows transition + prev/new IDs, then
    renders the new result inline (so reviewer sees the latest state)."""

    prev_id = (
        previous.diagnostic_plan.id if isinstance(previous, DiagnosticPlanResult)
        and previous.diagnostic_plan
        else (previous.plan.id if isinstance(previous, PlanResult) and previous.plan else "?")
    )
    new_id = (
        new_result.diagnostic_plan.id if isinstance(new_result, DiagnosticPlanResult)
        and new_result.diagnostic_plan
        else (new_result.plan.id if isinstance(new_result, PlanResult) and new_result.plan else "?")
    )
    new_trigger = ""
    if isinstance(new_result, PlanResult) and new_result.plan:
        new_trigger = new_result.plan.revision_trigger or ""
    elif isinstance(new_result, DiagnosticPlanResult) and new_result.diagnostic_plan:
        new_trigger = new_result.diagnostic_plan.revision_trigger or ""

    body: list[str] = []
    body.append(
        '<div class="doc-header">'
        '<div class="doc-label">OpenOnco · Revision Note</div>'
        '<div class="doc-title">Перегляд плану</div>'
        f'<div class="doc-sub">Transition: {_h(transition)} · {_h(_now_iso())}</div>'
        '</div>'
    )

    body.append(
        '<div class="banner banner--info">'
        f'<strong>Previous:</strong> {_h(prev_id)} → <strong>New:</strong> {_h(new_id)}<br>'
        f'<strong>Trigger:</strong> {_h(new_trigger or "(not specified)")}'
        '</div>'
    )

    # Inline render of the NEW result (delegate). The inner render handles
    # localization itself; here we render in UA and let the outer wrap
    # localize the entire revision-note HTML in one pass.
    if isinstance(new_result, DiagnosticPlanResult):
        inner = render_diagnostic_brief_html(new_result, mdt=mdt, target_lang="uk")
    else:
        inner = render_plan_html(new_result, mdt=mdt, target_lang="uk")
    start = inner.find('<div class="page">')
    end = inner.rfind('</div>\n</body>')
    if start >= 0 and end >= 0:
        body.append(inner[start + len('<div class="page">'):end])
    else:
        body.append(inner)

    out = _doc_shell("OpenOnco · Revision Note", "".join(body))
    return _localize_html(out, target_lang)


# ── Polymorphic dispatch ──────────────────────────────────────────────────


def render(
    result: Union[PlanResult, DiagnosticPlanResult],
    mdt: Optional[MDTOrchestrationResult] = None,
    *,
    target_lang: str = "uk",
) -> str:
    """Auto-dispatch by result type."""
    if isinstance(result, DiagnosticPlanResult):
        return render_diagnostic_brief_html(result, mdt=mdt, target_lang=target_lang)
    return render_plan_html(result, mdt=mdt, target_lang=target_lang)


__all__ = [
    "render",
    "render_diagnostic_brief_html",
    "render_plan_html",
    "render_revision_note_html",
]
